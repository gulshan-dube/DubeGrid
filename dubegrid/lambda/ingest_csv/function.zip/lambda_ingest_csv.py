import boto3
import csv
import io
import urllib.parse   # ⬅ NEW: to decode the S3 key

def lambda_handler(event, context):
    bucket = event['Records'][0]['s3']['bucket']['name']
    key    = event['Records'][0]['s3']['object']['key']

    # 🔍 Debug incoming S3 event values
    print(f"DEBUG — Incoming bucket: {bucket}")
    print(f"DEBUG — Incoming key:    {key}")

    # ✅ Decode URL‑encoded characters (e.g. %3D → =)
    key = urllib.parse.unquote_plus(key)

    s3 = boto3.client('s3')
    response = s3.get_object(Bucket=bucket, Key=key)
    content = response['Body'].read().decode('utf-8')
    reader = csv.DictReader(io.StringIO(content))

    for row in reader:
        print(row)

    return {'statusCode': 200, 'body': 'CSV processed'}

